package ugent.waves.healthrecommendersystems.services;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Vibrator;
import android.support.annotation.Nullable;
import android.util.Log;

import ugent.waves.healthrecommendersystems.persistance.AppDatabase;
import ugent.waves.healthrecommendersystems.persistance.accelerometerData;

public class SensorBackgroundService extends IntentService implements SensorEventListener {

    protected static final String TAG = "SensorBackgroundService";

    private SensorManager sensorManager;
    private Sensor accelerometer;

    private AppDatabase db;

    public SensorBackgroundService(){
        super(TAG);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        db = AppDatabase.getInstance(this);
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);

        } else {
            // fail! we dont have an accelerometer!
        }

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        //Log.d(TAG, "ACCELEROMETER "+ event.values[0] + " " + event.values[1] + " " + event.values[2]);
        accelerometerData data = new accelerometerData();
        data.xCoordinate = event.values[0];
        data.yCoordinate = event.values[1];
        data.zCoordinate = event.values[2];
        db.accelerometerDataDao().insertAccelerometerData(data);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
